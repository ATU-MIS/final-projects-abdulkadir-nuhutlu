# Usability Test

Participants: 5 students  
Average completion time: 45 seconds  

Result: System is easy to use.

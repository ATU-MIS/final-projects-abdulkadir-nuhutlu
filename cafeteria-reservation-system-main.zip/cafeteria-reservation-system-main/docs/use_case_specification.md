# Use Case Specification

Use Case: Make Cafeteria Reservation  
Actor: Student  

Main Flow:
1. Login
2. Select date & time
3. Check quota
4. Create reservation
5. Send notification

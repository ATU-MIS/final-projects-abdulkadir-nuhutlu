# Requirements Analysis

## Functional Requirements
- User login
- Make reservation
- Quota control
- Notification sending

## Non-Functional Requirements
- Easy to use
- Fast response

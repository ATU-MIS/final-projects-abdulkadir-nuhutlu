public class Reservation {
    private int reservationId;
    private int userId;
    private String date;
    private String timeSlot;
    private String status;

    public void create() {}
    public void cancel() {}
}

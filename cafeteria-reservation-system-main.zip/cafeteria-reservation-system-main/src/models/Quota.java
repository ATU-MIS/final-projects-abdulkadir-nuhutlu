public class Quota {
    private String date;
    private String timeSlot;
    private int maxCapacity;
    private int remainingCapacity;
}

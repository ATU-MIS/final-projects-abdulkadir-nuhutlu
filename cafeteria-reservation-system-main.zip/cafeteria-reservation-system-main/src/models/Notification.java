public class Notification {
    private int notificationId;
    private int userId;
    private String message;
}

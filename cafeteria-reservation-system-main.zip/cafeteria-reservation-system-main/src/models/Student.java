public class Student extends User {
    private String studentNo;

    public void makeReservation() {}
}

public class User {
    protected int userId;
    protected String name;
    protected String email;
    protected String password;

    public void login() {}
    public void logout() {}
}
